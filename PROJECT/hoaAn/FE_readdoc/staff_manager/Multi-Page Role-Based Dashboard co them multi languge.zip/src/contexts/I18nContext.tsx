import React, { createContext, useContext, useState, useEffect } from 'react';
import { LANGUAGES } from '../utils/constants';
import { translations } from '../locales/translations';

interface I18nContextType {
  language: string;
  setLanguage: (language: string) => void;
  t: (key: string, params?: Record<string, string>) => string;
}

const I18nContext = createContext<I18nContextType | undefined>(undefined);

export const useI18n = () => {
  const context = useContext(I18nContext);
  if (context === undefined) {
    throw new Error('useI18n must be used within an I18nProvider');
  }
  return context;
};

export const I18nProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<string>(LANGUAGES.EN);

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || LANGUAGES.EN;
    setLanguageState(savedLanguage);
  }, []);

  const setLanguage = (newLanguage: string) => {
    setLanguageState(newLanguage);
    localStorage.setItem('language', newLanguage);
  };

  const t = (key: string, params?: Record<string, string>): string => {
    const languageTranslations = translations[language as keyof typeof translations] || translations[LANGUAGES.EN];
    let translation = languageTranslations[key as keyof typeof languageTranslations] || key;
    
    if (params) {
      Object.keys(params).forEach(param => {
        translation = translation.replace(`{{${param}}}`, params[param]);
      });
    }
    
    return translation;
  };

  return (
    <I18nContext.Provider value={{
      language,
      setLanguage,
      t
    }}>
      {children}
    </I18nContext.Provider>
  );
};