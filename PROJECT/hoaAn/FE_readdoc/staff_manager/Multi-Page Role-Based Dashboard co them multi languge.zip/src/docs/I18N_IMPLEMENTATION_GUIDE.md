# I18n (Internationalization) Implementation Guide

## Tổng quan / Overview

Hệ thống POS đã được tích hợp đầy đủ tính năng đa ngôn ngữ (i18n) hỗ trợ **Tiếng Anh** và **Tiếng Việt**. Người dùng có thể chuyển đổi ngôn ngữ dễ dàng thông qua giao diện.

The POS system has been fully integrated with internationalization (i18n) features supporting **English** and **Vietnamese**. Users can easily switch languages through the interface.

---

## Cấu trúc / Structure

### 1. Translation Files
**Location:** `/locales/translations.ts`

File này chứa tất cả translations cho cả tiếng Anh và tiếng Việt, được tổ chức theo modules:

- **Navigation:** Menu items, navigation links
- **Common:** Buttons, labels, status messages
- **Modules:** Orders, Inventory, Staff, Tasks, CRM, LRM, HRM
- **Admin:** User Management, Audit Logs, System Settings, System Monitor
- **Auth:** Login, logout, authentication messages
- **Errors:** Error messages, validation messages
- **Success:** Success messages, confirmation messages
- **Pagination:** Pagination controls
- **Time & Date:** Relative time formatting

### 2. I18n Context
**Location:** `/contexts/I18nContext.tsx`

Provider để quản lý:
- Current language state
- Language switching
- Translation function `t(key, params?)`
- LocalStorage persistence

### 3. Language Switcher Component
**Location:** `/components/LanguageSwitcher.tsx`

Component dropdown để chuyển đổi ngôn ngữ với:
- Visual language flags (🇬🇧 🇻🇳)
- Current language indicator
- Available in TopBar và Login page

---

## Cách sử dụng / Usage

### Trong Components

```tsx
import { useI18n } from '../contexts/I18nContext';

const MyComponent = () => {
  const { t, language, setLanguage } = useI18n();
  
  return (
    <div>
      <h1>{t('nav.dashboard')}</h1>
      <p>{t('dashboard.welcome', { name: 'John' })}</p>
      <button onClick={() => setLanguage('vi')}>
        Switch to Vietnamese
      </button>
    </div>
  );
};
```

### Translation với Parameters

```tsx
// Translation key trong translations.ts:
// 'dashboard.welcome': 'Welcome back, {{name}}!'

// Trong component:
const name = user?.name || 'Guest';
const welcomeMessage = t('dashboard.welcome', { name });
// Output: "Welcome back, John!"
```

### Checking Current Language

```tsx
const { language } = useI18n();

if (language === LANGUAGES.VI) {
  // Do something specific for Vietnamese
}
```

---

## Translation Keys Organization

### Naming Convention

```
<module>.<section>.<item>
```

Examples:
- `nav.dashboard` - Navigation: Dashboard
- `orders.myOrders` - Orders module: My Orders
- `common.save` - Common: Save button
- `admin.users.title` - Admin module > Users section: Title
- `error.generic` - Error messages: Generic error

### Common Prefixes

- `nav.*` - Navigation items
- `common.*` - Common UI elements (buttons, labels, status)
- `orders.*` - Orders module
- `inventory.*` - Inventory module
- `staff.*` - Staff module
- `tasks.*` - Tasks module
- `crm.*` - CRM module
- `lrm.*` - LRM module
- `hrm.*` - HRM module
- `admin.*` - Admin modules
- `auth.*` - Authentication
- `error.*` - Error messages
- `success.*` - Success messages
- `confirm.*` - Confirmation messages
- `pagination.*` - Pagination controls
- `time.*` - Time and date formatting

---

## Thêm Translation Keys Mới / Adding New Translation Keys

### Step 1: Add to translations.ts

```typescript
// In /locales/translations.ts

export const translations = {
  [LANGUAGES.EN]: {
    // ... existing translations
    'myModule.myKey': 'My English Text',
  },
  [LANGUAGES.VI]: {
    // ... existing translations
    'myModule.myKey': 'Văn bản tiếng Việt',
  },
};
```

### Step 2: Use in Component

```tsx
const { t } = useI18n();

return <h1>{t('myModule.myKey')}</h1>;
```

---

## Các Pages đã được i18n hoàn chỉnh / Fully i18n Pages

✅ **Login Page** - Language switcher available
✅ **Dashboard** - All text translated
✅ **Orders Page** - Filters, table headers, actions
✅ **Notifications Page** - Full translation support
✅ **Profile Page** - Settings, preferences, account info
✅ **Sidebar Navigation** - All menu items
✅ **Top Bar** - User menu, settings

### Các pages cần cập nhật / Pages to Update

🔄 **Inventory Page** - Needs full translation
🔄 **Tasks Page** - Needs full translation  
🔄 **Staff Page** - Needs full translation
🔄 **Analytics Page** - Needs full translation
🔄 **CRM, LRM, HRM Pages** - Partial translations exist
🔄 **Admin Pages** - Translations defined, need implementation

---

## Best Practices

### 1. Always use translation keys

❌ **DON'T:**
```tsx
<button>Save</button>
```

✅ **DO:**
```tsx
<button>{t('common.save')}</button>
```

### 2. Use parameters for dynamic content

❌ **DON'T:**
```tsx
<p>Order #{order.id} has been created</p>
```

✅ **DO:**
```tsx
// In translations.ts:
// 'orders.created': 'Order #{{id}} has been created'

<p>{t('orders.created', { id: order.id })}</p>
```

### 3. Organize keys logically

Group related translations together:
```typescript
// Good organization
'inventory.addProduct': 'Add Product'
'inventory.editProduct': 'Edit Product'
'inventory.deleteProduct': 'Delete Product'

// Bad organization - scattered keys
'addProduct': 'Add Product'
'edit': 'Edit Product'
'deleteInventoryProduct': 'Delete Product'
```

### 4. Provide context in key names

❌ **TOO GENERIC:**
```typescript
'title': 'Title'
'subtitle': 'Subtitle'
```

✅ **BETTER:**
```typescript
'orders.title': 'Orders Management'
'orders.subtitle': 'View and manage all orders'
```

### 5. Keep translations consistent

Use the same terms across the application:
- "Orders" not "Orders" in one place and "Purchase Orders" in another
- "Customer" not "Customer" and "Client" interchangeably
- "Staff" not "Staff", "Employee", "Worker" mixed

---

## Language Switching

### User Interface Locations

1. **Top Bar** - Global language switcher (always visible when logged in)
2. **Login Page** - Top-right corner language switcher
3. **Profile Page** - Language preference in settings

### Persistence

The selected language is automatically saved to `localStorage` and will persist across:
- Page refreshes
- Browser sessions
- Different tabs

### Default Language

Default language is **English** (`LANGUAGES.EN`)

To change the default, modify `/contexts/I18nContext.tsx`:

```tsx
const [language, setLanguageState] = useState<string>(LANGUAGES.VI); // Change to VI
```

---

## Testing i18n

### Manual Testing Checklist

1. ✅ Switch language from Top Bar
2. ✅ Verify all visible text changes
3. ✅ Check that language persists on refresh
4. ✅ Test dynamic content with parameters
5. ✅ Verify error messages are translated
6. ✅ Check success notifications
7. ✅ Test all navigation labels
8. ✅ Verify dropdown/select options

### Test Different Pages

- [ ] Login Page
- [ ] Dashboard
- [ ] Orders
- [ ] Inventory
- [ ] Staff
- [ ] Tasks
- [ ] Analytics
- [ ] CRM, LRM, HRM
- [ ] Profile
- [ ] Admin pages

---

## Future Enhancements

### Additional Languages

To add a new language (e.g., French):

1. **Add constant:**
```typescript
// In /utils/constants.ts
export const LANGUAGES = {
  EN: 'en',
  VI: 'vi',
  FR: 'fr', // New language
} as const;
```

2. **Add translations:**
```typescript
// In /locales/translations.ts
export const translations = {
  [LANGUAGES.EN]: { /* ... */ },
  [LANGUAGES.VI]: { /* ... */ },
  [LANGUAGES.FR]: { /* French translations */ },
};
```

3. **Update LanguageSwitcher:**
```tsx
const languages = [
  { code: LANGUAGES.EN, label: 'English', flag: '🇬🇧' },
  { code: LANGUAGES.VI, label: 'Tiếng Việt', flag: '🇻🇳' },
  { code: LANGUAGES.FR, label: 'Français', flag: '🇫🇷' }, // New
];
```

### Language Detection

Implement automatic language detection based on:
- Browser language preference
- User's location (IP-based)
- Previous user preference

### RTL Support

For right-to-left languages (Arabic, Hebrew):
- Add RTL detection
- Apply RTL layout classes
- Mirror icons and UI elements

---

## Troubleshooting

### Translation key not found

**Issue:** Text shows as key name (e.g., `nav.dashboard` instead of "Dashboard")

**Solution:**
1. Check if key exists in `/locales/translations.ts`
2. Verify correct spelling
3. Check both EN and VI have the key

### Language not persisting

**Issue:** Language resets on refresh

**Solution:**
1. Check browser localStorage is enabled
2. Verify I18nProvider is wrapping the app in `/App.tsx`
3. Check console for errors

### Parameters not working

**Issue:** Placeholders not replaced (e.g., "Welcome {{name}}")

**Solution:**
```tsx
// Correct usage:
t('dashboard.welcome', { name: user.name })

// NOT:
t('dashboard.welcome', { userName: user.name }) // Wrong param name
```

---

## Support

For questions or issues:
1. Check this documentation
2. Review `/locales/translations.ts` for available keys
3. Check component examples in `/pages/` and `/components/`
4. Review the Context implementation in `/contexts/I18nContext.tsx`

---

## Summary / Tóm tắt

✅ **Supported Languages:** English, Vietnamese
✅ **Translation Keys:** 500+ keys covering all modules
✅ **Components:** LanguageSwitcher component
✅ **Pages:** Major pages fully translated
✅ **Storage:** LocalStorage persistence
✅ **Easy to extend:** Add new languages or keys easily

The i18n system is production-ready and can be easily extended with additional languages or translation keys as needed.
