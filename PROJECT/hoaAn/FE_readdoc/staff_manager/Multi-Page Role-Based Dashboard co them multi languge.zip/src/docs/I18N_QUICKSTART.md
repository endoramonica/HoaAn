# Hướng dẫn nhanh Đa ngôn ngữ / i18n Quick Start

## 🌐 Tổng quan / Overview

Hệ thống POS hỗ trợ đầy đủ **Tiếng Anh** và **Tiếng Việt** với khả năng chuyển đổi ngôn ngữ real-time.

---

## 🚀 Cách sử dụng / How to Use

### 1. Chuyển đổi ngôn ngữ / Switch Language

**Từ giao diện / From UI:**
- **Top Bar** (góc phải) → Click icon 🌐
- **Login Page** (góc trên phải) → Click icon 🌐  
- **Profile Page** → Preferences → Language dropdown

**Bằng code:**
```tsx
import { useI18n } from '../contexts/I18n Context';

const { setLanguage } = useI18n();
setLanguage('vi'); // Vietnamese
setLanguage('en'); // English
```

### 2. Sử dụng translations trong component / Use translations in components

```tsx
import { useI18n } from '../contexts/I18nContext';

const MyComponent = () => {
  const { t } = useI18n();
  
  return (
    <div>
      <h1>{t('nav.dashboard')}</h1>
      <button>{t('common.save')}</button>
    </div>
  );
};
```

### 3. Translations với tham số / Translations with parameters

```tsx
const { t } = useI18n();

// Translation key: 'dashboard.welcome': 'Welcome back, {{name}}!'
const message = t('dashboard.welcome', { name: 'John' });
// Output: "Welcome back, John!"
```

---

## 📂 Cấu trúc / Structure

```
/locales
  └── translations.ts          # Tất cả translations (EN + VI)
  
/contexts
  └── I18nContext.tsx           # i18n Provider & hook
  
/components
  └── LanguageSwitcher.tsx      # Language dropdown component
```

---

## 🔑 Translation Keys phổ biến / Common Translation Keys

### Navigation
```typescript
t('nav.dashboard')      // Dashboard / Bảng điều khiển
t('nav.orders')         // Orders / Đơn hàng
t('nav.inventory')      // Inventory / Kho hàng
t('nav.staff')          // Staff / Nhân viên
```

### Common Actions
```typescript
t('common.save')        // Save / Lưu
t('common.cancel')      // Cancel / Hủy
t('common.delete')      // Delete / Xóa
t('common.edit')        // Edit / Sửa
t('common.add')         // Add / Thêm
t('common.search')      // Search / Tìm kiếm
t('common.filter')      // Filter / Lọc
t('common.export')      // Export / Xuất
```

### Status
```typescript
t('common.pending')     // Pending / Chờ xử lý
t('common.completed')   // Completed / Hoàn thành
t('common.cancelled')   // Cancelled / Đã hủy
t('common.active')      // Active / Hoạt động
```

### Orders Module
```typescript
t('orders.title')           // Orders Management
t('orders.myOrders')        // My Orders / Đơn hàng của tôi
t('orders.allOrders')       // All Orders / Tất cả đơn hàng
t('orders.newOrder')        // New Order / Đơn hàng mới
t('orders.orderDetails')    // Order Details / Chi tiết đơn hàng
```

### Authentication
```typescript
t('auth.login')             // Login / Đăng nhập
t('auth.logout')            // Logout / Đăng xuất
t('auth.email')             // Email
t('auth.password')          // Password / Mật khẩu
```

### Errors
```typescript
t('error.generic')          // An error occurred...
t('error.network')          // Network error...
t('error.unauthorized')     // You are not authorized...
```

---

## ✅ Pages đã hoàn thành / Completed Pages

- ✅ Login Page
- ✅ Dashboard
- ✅ Orders Page
- ✅ Notifications Page
- ✅ Profile Page
- ✅ Sidebar & TopBar

---

## 📝 Thêm translation mới / Add new translations

### Step 1: Thêm vào translations.ts
```typescript
// /locales/translations.ts
export const translations = {
  [LANGUAGES.EN]: {
    'myModule.myKey': 'My English Text',
  },
  [LANGUAGES.VI]: {
    'myModule.myKey': 'Văn bản tiếng Việt của tôi',
  },
};
```

### Step 2: Sử dụng trong component
```tsx
const { t } = useI18n();
<h1>{t('myModule.myKey')}</h1>
```

---

## 🎯 Best Practices

### ✅ DO (Nên làm)
```tsx
// Use translation keys
<button>{t('common.save')}</button>

// Use parameters for dynamic content
t('dashboard.welcome', { name: user.name })

// Organize keys logically
'orders.title'
'orders.newOrder'
'orders.orderDetails'
```

### ❌ DON'T (Không nên)
```tsx
// Hardcode text
<button>Save</button>

// String concatenation
`Welcome ${user.name}!`

// Scattered key names
'title'
'new'
'details'
```

---

## 🔄 Kiểm tra ngôn ngữ hiện tại / Check current language

```tsx
import { useI18n } from '../contexts/I18nContext';
import { LANGUAGES } from '../utils/constants';

const { language } = useI18n();

if (language === LANGUAGES.VI) {
  // Vietnamese specific logic
}

if (language === LANGUAGES.EN) {
  // English specific logic
}
```

---

## 🎨 Language Switcher Component

```tsx
import { LanguageSwitcher } from '../components/LanguageSwitcher';

// Anywhere in your component
<LanguageSwitcher />
```

---

## 💾 Lưu trữ / Storage

- Ngôn ngữ được lưu tự động vào `localStorage`
- Persist qua các sessions
- Default: English

---

## 🌟 Tính năng / Features

✅ **Real-time switching** - Chuyển đổi ngay lập tức
✅ **Persistent** - Lưu trữ preference
✅ **500+ keys** - Bao phủ toàn bộ hệ thống
✅ **Parameter support** - Dynamic content
✅ **Easy to extend** - Thêm ngôn ngữ mới dễ dàng

---

## 📖 Chi tiết / More Details

Xem tài liệu đầy đủ: `/docs/I18N_IMPLEMENTATION_GUIDE.md`

---

## 🆘 Troubleshooting

**Q: Tại sao text hiển thị dạng key (vd: 'nav.dashboard')?**
A: Key chưa được định nghĩa trong `/locales/translations.ts`

**Q: Ngôn ngữ không lưu khi refresh?**
A: Kiểm tra localStorage có được enable không

**Q: Parameters không hoạt động?**
A: Đảm bảo tên parameter khớp với template trong translations

---

## 📞 Hỗ trợ / Support

- 📄 Full Documentation: `/docs/I18N_IMPLEMENTATION_GUIDE.md`
- 🔧 Translation Files: `/locales/translations.ts`
- ⚙️ Context: `/contexts/I18nContext.tsx`
- 🎨 Component: `/components/LanguageSwitcher.tsx`

---

**Happy translating! / Chúc bạn code vui vẻ! 🎉**
